package br.edu.ifpb.catalogo_ecommerce.service;

import br.edu.ifpb.catalogo_ecommerce.exception.EntidadeNaoEncontradaException;
import br.edu.ifpb.catalogo_ecommerce.exception.NenhumaEntidadeEncontradaException;
import br.edu.ifpb.catalogo_ecommerce.repository.BaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public abstract class BaseService<T> {

    private final BaseRepository<T> repository;

    protected BaseService(BaseRepository<T> repository) {
        this.repository = repository;
    }

    public String criar(T entidade){
        return repository.criar(entidade);
    }

    public String salvar(String id, T entidade){
        return repository.salvar(id, entidade);
    }

    public Optional<T> buscarPorId(String id){
        Optional<T> entidadeEncontrada = repository.buscarPorId(id);
        if(entidadeEncontrada.isEmpty()){
            throw new EntidadeNaoEncontradaException(entidadeEncontrada.get().getClass().getName(), id);
        }
        return entidadeEncontrada;
    }

    public List<T> buscarTodos(){
        List<T> entidadesEncontradas = repository.listarTodos();
        if(entidadesEncontradas.isEmpty()){
            throw new NenhumaEntidadeEncontradaException(entidadesEncontradas.getFirst().getClass().getName());
        }
        return entidadesEncontradas;
    }

    public void deletar(String id){
        Optional<T> entidadeEncontrada = buscarPorId(id);
        if(entidadeEncontrada.isEmpty()){
            throw new EntidadeNaoEncontradaException(entidadeEncontrada.get().getClass().getName(), id);
        }
        repository.deletar(id);
    }


}
