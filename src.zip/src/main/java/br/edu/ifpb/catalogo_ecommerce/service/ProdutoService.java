package br.edu.ifpb.catalogo_ecommerce.service;

import br.edu.ifpb.catalogo_ecommerce.model.produto.Produto;
import br.edu.ifpb.catalogo_ecommerce.repository.BaseRepository;

public class ProdutoService extends BaseService<Produto> {
    
    protected ProdutoService(BaseRepository<Produto> repository) {
        super(repository);
    }
}
