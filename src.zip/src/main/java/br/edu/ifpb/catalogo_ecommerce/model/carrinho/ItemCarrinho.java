package br.edu.ifpb.catalogo_ecommerce.model.carrinho;

import br.edu.ifpb.catalogo_ecommerce.model.produto.Produto;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class ItemCarrinho {

    private String produtoId;
    private String nome;
    private long precoEmCentavos;
    private int quantidade;

    public ItemCarrinho(Produto produto, int quantidade) {
        this.produtoId = produto.getId();
        this.nome = produto.getNome();
        this.precoEmCentavos = produto.getPrecoEmCentavos();
        this.quantidade = quantidade;
    }

    public long getSubtotal() {
        return precoEmCentavos * quantidade;
    }

}
